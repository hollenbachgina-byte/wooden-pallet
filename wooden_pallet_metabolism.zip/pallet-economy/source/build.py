import json
d=lambda f: json.load(open("data/"+f))
F=d("map_flows.json"); F["material"]+= [dict(id="circulation-peco",source="circulation",target="peco"),dict(id="circulation-igps",source="circulation",target="igps")]
DATA=dict(events=d("events.json"),images=d("event_images.json"),curve=d("volume_curve.json"),prod=d("production.json"),map=dict(elements=d("map_elements.json"),flows=F,loops=d("loops.json"),phases=d("phases.json"),species=d("species.json")))
s=open("site/src.html").read().replace("__DATA__",json.dumps(DATA).replace("</","<\\/")).replace("__SYM__",open("lib/symbols.js").read()).replace("__MAP__",open("lib/map.js").read())
import base64
s=s.replace("__PALLET_IMG__","data:image/jpeg;base64,"+base64.b64encode(open("assets/pallet_intro.jpg","rb").read()).decode())
s=s.replace("__PALLET_CUT__","data:image/png;base64,"+base64.b64encode(open("assets/pallet_cutout.png","rb").read()).decode())
open("site/index.html","w").write(s); print(len(s))
