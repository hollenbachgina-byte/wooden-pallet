# The Wooden Pallet

A scroll-driven website about the US wooden pallet economy: its history, how many pallets exist today, and the system of production, use, repair, recycling and disposal that keeps them moving.

**Julius Staudenmaier, Hamza Molvi, Gina Hollenbach, Lily Seckendorf**
SCI 6372: Circuits, Circles, and Loops: Towards a Regenerative Architecture

## Viewing the site

Open `index.html` in any web browser (Chrome, Safari, Firefox or Edge). Everything, including every photo and all the data, is built into that one file, so it works offline. The only thing loaded from the internet is the Jost typeface; without a connection the page falls back to a similar font.

## Hosting it on GitHub Pages

1. Sign in at github.com and create a new **public** repository, for example `wooden-pallet`.
2. On the repository page, choose **Add file → Upload files**.
3. Drag in `index.html`, `README.md`, `.nojekyll` and the `source` folder. (On a Mac, press Cmd + Shift + . in Finder to see `.nojekyll`, which is hidden because its name starts with a dot. It's optional; the site works without it.)
4. Click **Commit changes**.
5. Go to **Settings → Pages**. Under "Build and deployment", set Source to **Deploy from a branch**, pick the **main** branch and the **/ (root)** folder, and click **Save**.
6. After a minute or two, the site is live at `https://YOUR-USERNAME.github.io/wooden-pallet/`. The address appears at the top of the Pages settings once it's ready.

## Editing the site

The `source` folder holds the editable files. The site is built from them into the single `index.html`.

- `site/src.html`: the page layout, styles and scrolling code
- `data/events.json`: the timeline cards
- `data/event_images.json`: the timeline photos (black and white, embedded)
- `data/production.json`: the pallet production series and circulation total behind the timeline line
- `data/map_elements.json`, `map_flows.json`, `loops.json`, `phases.json`: the systems map
- `lib/map.js`, `lib/symbols.js`: the systems map drawing code
- `assets/`: the color pallet photos on the intro slides

To rebuild after editing, install Python 3, then run this from inside the `source` folder:

```
python3 build.py
```

This writes a new `site/index.html`. Copy it over the `index.html` at the top level (and into your GitHub repository) to update the site.

## Sources and images

Every figure in the timeline line, the fact boxes and the systems map links to its source inside the site. Several photos come from archives, manufacturers and publications. Before making the site public, check that you're allowed to share them, particularly the Pallet Design System specification sheet, which says it may not be reproduced without permission from the NWPCA (now Woodpack Global).
